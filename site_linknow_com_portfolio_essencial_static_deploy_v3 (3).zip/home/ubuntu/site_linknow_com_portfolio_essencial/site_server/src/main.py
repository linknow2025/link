from flask import Flask, send_from_directory, jsonify
import os

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Rotas para servir arquivos estáticos
@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static_files(path):
    return send_from_directory(app.static_folder, path)

@app.route('/portfolio/importacao_inteligente/')
def serve_importacao():
    return send_from_directory(os.path.join(app.static_folder, 'portfolio', 'importacao_inteligente'), 'index.html')

@app.route('/portfolio/bots_contabilidade/')
def serve_bots_contabilidade():
    return send_from_directory(os.path.join(app.static_folder, 'portfolio', 'bots_contabilidade'), 'index.html')

# Exemplo de rota de API (se houver)
@app.route('/api/data')
def get_data():
    return jsonify({'message': 'Dados da API!'})

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)



