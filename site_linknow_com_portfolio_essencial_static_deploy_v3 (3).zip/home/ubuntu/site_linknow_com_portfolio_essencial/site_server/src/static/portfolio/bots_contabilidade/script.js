document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById("download-form");
    
    if (form) {
        form.addEventListener("submit", function(event) {
            event.preventDefault();
            
            const nameInput = this.querySelector("input[type='text']");
            const emailInput = this.querySelector("input[type='email']");
            
            if (nameInput && emailInput) {
                const name = nameInput.value;
                const email = emailInput.value;
                
                // Aqui você pode adicionar a lógica para enviar os dados para o seu sistema de leads
                console.log("Nome: " + name + ", Email: " + email);
                
                // Simula o download do e-book
                alert("Obrigado " + name + "! Seu e-book foi enviado para " + email + ".");
                
                // Cria um link de download simulado
                const link = document.createElement('a');
                link.href = 'data:text/plain;charset=utf-8,E-book: Bots em Empresas de Contabilidade\n\nObrigado por baixar nosso e-book!\n\nEste é um exemplo de conteúdo do e-book sobre bots em empresas de contabilidade.';
                link.download = 'bots-empresas-contabilidade.txt';
                link.style.display = 'none';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                this.reset();
            }
        });
    }
});

