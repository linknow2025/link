// Sistema de Captura de Leads - LinkNow
class LeadCapture {
    constructor() {
        this.init();
        this.setupEventListeners();
        this.startTimers();
    }

    init() {
        this.createLeadModal();
        this.createFloatingButton();
        this.createExitIntentModal();
        this.loadLeadData();
    }

    createLeadModal() {
        const modalHTML = `
            <div id="leadModal" class="lead-modal" style="display: none;">
                <div class="lead-modal-content">
                    <span class="lead-modal-close">&times;</span>
                    <div class="lead-modal-header">
                        <h2>🎁 Oferta Especial!</h2>
                        <p>Receba nosso E-book GRATUITO sobre Marketing Digital</p>
                    </div>
                    <form id="leadForm" class="lead-form">
                        <div class="form-group">
                            <input type="text" id="leadName" name="name" placeholder="Seu nome completo" required>
                        </div>
                        <div class="form-group">
                            <input type="email" id="leadEmail" name="email" placeholder="Seu melhor e-mail" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" id="leadPhone" name="phone" placeholder="Seu WhatsApp (opcional)">
                        </div>
                        <button type="submit" class="lead-submit-btn">
                            📥 BAIXAR E-BOOK GRÁTIS
                        </button>
                        <p class="lead-privacy">
                            Seus dados estão seguros. Não enviamos spam.
                        </p>
                    </form>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    createFloatingButton() {
        const buttonHTML = `
            <div id="floatingLeadBtn" class="floating-lead-btn">
                <span>📧</span>
                <div class="floating-tooltip">E-book Grátis!</div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', buttonHTML);
    }

    createExitIntentModal() {
        const exitModalHTML = `
            <div id="exitIntentModal" class="lead-modal exit-intent-modal" style="display: none;">
                <div class="lead-modal-content">
                    <span class="lead-modal-close">&times;</span>
                    <div class="lead-modal-header exit-intent-header">
                        <h2>⚠️ Espere!</h2>
                        <p>Antes de sair, que tal levar nosso E-book GRATUITO?</p>
                        <p class="exit-offer">+ BÔNUS: Checklist de Marketing Digital</p>
                    </div>
                    <form id="exitLeadForm" class="lead-form">
                        <div class="form-group">
                            <input type="text" name="name" placeholder="Seu nome completo" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" placeholder="Seu melhor e-mail" required>
                        </div>
                        <button type="submit" class="lead-submit-btn exit-btn">
                            🎁 QUERO MEU E-BOOK + BÔNUS GRÁTIS
                        </button>
                        <p class="lead-privacy">
                            100% gratuito. Sem pegadinhas.
                        </p>
                    </form>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', exitModalHTML);
    }

    setupEventListeners() {
        // Modal principal
        const modal = document.getElementById('leadModal');
        const closeBtn = modal.querySelector('.lead-modal-close');
        const form = document.getElementById('leadForm');

        // Modal de exit intent
        const exitModal = document.getElementById('exitIntentModal');
        const exitCloseBtn = exitModal.querySelector('.lead-modal-close');
        const exitForm = document.getElementById('exitLeadForm');

        // Botão flutuante
        const floatingBtn = document.getElementById('floatingLeadBtn');

        // Event listeners
        closeBtn.addEventListener('click', () => this.closeModal('leadModal'));
        exitCloseBtn.addEventListener('click', () => this.closeModal('exitIntentModal'));
        floatingBtn.addEventListener('click', () => this.showModal('leadModal'));

        // Fechar modal clicando fora
        window.addEventListener('click', (e) => {
            if (e.target === modal) this.closeModal('leadModal');
            if (e.target === exitModal) this.closeModal('exitIntentModal');
        });

        // Formulários
        form.addEventListener('submit', (e) => this.handleFormSubmit(e, 'main'));
        exitForm.addEventListener('submit', (e) => this.handleFormSubmit(e, 'exit'));

        // Exit intent
        document.addEventListener('mouseleave', (e) => this.handleExitIntent(e));

        // Scroll tracking
        window.addEventListener('scroll', () => this.handleScroll());
    }

    startTimers() {
        // Modal após 30 segundos
        setTimeout(() => {
            if (!this.hasShownModal && !this.hasSubmittedLead()) {
                this.showModal('leadModal');
                this.hasShownModal = true;
            }
        }, 30000);

        // Modal após 60% do tempo na página
        setTimeout(() => {
            if (!this.hasShownModal && !this.hasSubmittedLead()) {
                this.showModal('leadModal');
                this.hasShownModal = true;
            }
        }, 45000);
    }

    showModal(modalId) {
        if (this.hasSubmittedLead()) return;
        
        const modal = document.getElementById(modalId);
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
        // Analytics
        this.trackEvent('modal_shown', { type: modalId });
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    handleFormSubmit(e, type) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone') || '',
            source: window.location.pathname,
            type: type,
            timestamp: new Date().toISOString()
        };

        this.submitLead(data, e.target);
    }

    async submitLead(data, form) {
        const submitBtn = form.querySelector('.lead-submit-btn');
        const originalText = submitBtn.innerHTML;
        
        submitBtn.innerHTML = '⏳ Enviando...';
        submitBtn.disabled = true;

        try {
            // Simular envio para servidor
            await this.sendToServer(data);
            
            // Salvar localmente
            this.saveLeadLocally(data);
            
            // Mostrar sucesso
            this.showSuccessMessage(form);
            
            // Fechar modal após 3 segundos
            setTimeout(() => {
                this.closeModal('leadModal');
                this.closeModal('exitIntentModal');
            }, 3000);

            // Redirecionar para página de obrigado
            setTimeout(() => {
                window.location.href = 'obrigado.html';
            }, 2000);

        } catch (error) {
            console.error('Erro ao enviar lead:', error);
            submitBtn.innerHTML = '❌ Erro. Tente novamente';
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        }
    }

    async sendToServer(data) {
        // Aqui você pode integrar com seu sistema de CRM/Email Marketing
        // Exemplo: Mailchimp, RD Station, HubSpot, etc.
        
        return new Promise((resolve) => {
            setTimeout(() => {
                console.log('Lead enviado:', data);
                resolve(data);
            }, 1000);
        });
    }

    saveLeadLocally(data) {
        localStorage.setItem('leadSubmitted', 'true');
        localStorage.setItem('leadData', JSON.stringify(data));
    }

    hasSubmittedLead() {
        return localStorage.getItem('leadSubmitted') === 'true';
    }

    showSuccessMessage(form) {
        form.innerHTML = `
            <div class="success-message">
                <h3>✅ Sucesso!</h3>
                <p>Seu e-book foi enviado para seu e-mail!</p>
                <p>Verifique sua caixa de entrada e spam.</p>
            </div>
        `;
    }

    handleExitIntent(e) {
        if (e.clientY <= 0 && !this.hasShownExitIntent && !this.hasSubmittedLead()) {
            this.showModal('exitIntentModal');
            this.hasShownExitIntent = true;
        }
    }

    handleScroll() {
        const scrollPercent = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
        
        if (scrollPercent > 70 && !this.hasShownScrollModal && !this.hasSubmittedLead()) {
            setTimeout(() => {
                if (!this.hasShownModal) {
                    this.showModal('leadModal');
                    this.hasShownScrollModal = true;
                }
            }, 2000);
        }
    }

    loadLeadData() {
        this.hasShownModal = false;
        this.hasShownExitIntent = false;
        this.hasShownScrollModal = false;
    }

    trackEvent(event, data) {
        // Integração com Google Analytics ou outro sistema de analytics
        if (typeof gtag !== 'undefined') {
            gtag('event', event, data);
        }
        console.log('Event tracked:', event, data);
    }
}

// Inicializar sistema de leads quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    new LeadCapture();
});

// CSS para o sistema de leads
const leadStyles = `
<style>
.lead-modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    justify-content: center;
    align-items: center;
    animation: fadeIn 0.3s ease;
}

.lead-modal-content {
    background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    max-width: 500px;
    width: 90%;
    position: relative;
    animation: slideIn 0.3s ease;
}

.lead-modal-close {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    color: #999;
    transition: color 0.3s;
}

.lead-modal-close:hover {
    color: #333;
}

.lead-modal-header {
    text-align: center;
    margin-bottom: 2rem;
}

.lead-modal-header h2 {
    color: #1E5EBF;
    margin-bottom: 0.5rem;
    font-size: 1.8rem;
}

.lead-modal-header p {
    color: #666;
    font-size: 1.1rem;
}

.exit-intent-header {
    background: linear-gradient(135deg, #ff6b6b, #ee5a24);
    color: white;
    padding: 1.5rem;
    border-radius: 10px;
    margin: -2rem -2rem 2rem -2rem;
}

.exit-intent-header h2,
.exit-intent-header p {
    color: white;
}

.exit-offer {
    background: rgba(255, 255, 255, 0.2);
    padding: 0.5rem;
    border-radius: 5px;
    font-weight: bold;
}

.lead-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.form-group input {
    width: 100%;
    padding: 1rem;
    border: 2px solid #e1e8ed;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s;
}

.form-group input:focus {
    outline: none;
    border-color: #1E5EBF;
    box-shadow: 0 0 0 3px rgba(30, 94, 191, 0.1);
}

.lead-submit-btn {
    background: linear-gradient(135deg, #1E5EBF, #3498DB);
    color: white;
    border: none;
    padding: 1.2rem 2rem;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
}

.lead-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(30, 94, 191, 0.3);
}

.exit-btn {
    background: linear-gradient(135deg, #ff6b6b, #ee5a24);
}

.lead-privacy {
    text-align: center;
    font-size: 0.9rem;
    color: #666;
    margin-top: 0.5rem;
}

.floating-lead-btn {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #1E5EBF, #3498DB);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(30, 94, 191, 0.4);
    z-index: 9999;
    transition: transform 0.3s, box-shadow 0.3s;
    animation: pulse 2s infinite;
}

.floating-lead-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 25px rgba(30, 94, 191, 0.6);
}

.floating-lead-btn span {
    font-size: 24px;
    color: white;
}

.floating-tooltip {
    position: absolute;
    bottom: 70px;
    right: 0;
    background: #333;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 5px;
    font-size: 0.9rem;
    white-space: nowrap;
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s;
    pointer-events: none;
}

.floating-lead-btn:hover .floating-tooltip {
    opacity: 1;
    transform: translateY(0);
}

.success-message {
    text-align: center;
    padding: 2rem;
}

.success-message h3 {
    color: #27ae60;
    margin-bottom: 1rem;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

@keyframes pulse {
    0% { box-shadow: 0 4px 20px rgba(30, 94, 191, 0.4); }
    50% { box-shadow: 0 4px 30px rgba(30, 94, 191, 0.8); }
    100% { box-shadow: 0 4px 20px rgba(30, 94, 191, 0.4); }
}

@media (max-width: 768px) {
    .lead-modal-content {
        margin: 1rem;
        padding: 1.5rem;
    }
    
    .floating-lead-btn {
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
    }
    
    .floating-lead-btn span {
        font-size: 20px;
    }
}
</style>
`;

// Adicionar estilos ao head
document.head.insertAdjacentHTML('beforeend', leadStyles);

