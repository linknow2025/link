from flask import Flask, jsonify
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = "asdf#FGSgvasgf$5$WGT"

# Exemplo de rota de API
@app.route("/api/data")
def get_data():
    return jsonify({"message": "Dados da API!"})

# Rotas para servir as páginas HTML específicas via função (se necessário)
# No entanto, é preferível que o Netlify sirva arquivos estáticos diretamente.
# Estas rotas são mantidas aqui para demonstração de como uma função pode servir HTML.
@app.route("/portfolio/importacao_inteligente/")
def serve_importacao_function():
    # Isso é um exemplo. Em um cenário real, você pode ler o HTML de um arquivo
    # ou renderizar um template aqui.
    return "<h1>Página de Importação Inteligente (via Netlify Function)</h1>"

@app.route("/portfolio/bots_contabilidade/")
def serve_bots_contabilidade_function():
    return "<h1>Página de Bots em Empresas de Contabilidade (via Netlify Function)</h1>"

from netlify_lambda_wsgi import handle_request

def handler(event, context):
    return handle_request(app, event, context)


